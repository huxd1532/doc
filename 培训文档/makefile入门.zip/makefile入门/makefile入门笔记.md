

#### 前言

​		当我还在学校的时候，用着Microsoft Visual Studio，Dev-C++，IDEA，这种集成开发环境的来写代码的时候，我是对makefile一无所知，这种关键词都出现不到我的面前。后来接触到Linux平台后，发现写代码还要通过gcc编译器来编译，而不是在Microsoft Visual Studio点击一下运行知道编译。学习总归是一件好的事情。于是我开始来看gcc和makefile。

​		什么是gcc？它是由GNU开发的编程语言译器。简单来说就是把我们写好的源代码翻译成计算机认识的可执行的二进制程序。

​		下面我写一个简单的C语言的程序：写一个简单的hello.c文件

```c
#include<stdio.h>

int main()
{
    printf("hello uos\n");
    return 0;
}
```

我们可以用gcc 来编译它。

```
gcc hello.c -o hello
```

上面那条命令的意思是通过gcc来编译hello.c文件，然后生成一个叫hello的可执行程序。

当然我现在需要讲的是makefile，所有gcc的相关我就只简单的提一下。

什么是makefile？ 

​		很多 Linux(Unix) 做开发的初学者不了解 Makefile 是什么，甚至大部分 Windows 开发工程师对 Makefile 都特别陌生。这个其实很正常，如果你是在 Windows 下作开发的话不需要去考虑这个问题，因为 Windows 下的集成开发环境（IDE）已经内置了 Makefile，或者说会自动生成 Makefile，我们不用去手动编写。

​		makefile 可以简单的认为是一个工程文件的编译规则，描述了整个工程的编译和链接等规则。里面定义了一系列的规则指定`哪些文件需要先编译，哪些文件需要后编译，哪些文件需要重新编译`，它记录了源代码如何编译的详细信息！ makefile一旦写好，只需要一个make命令，整个工程完全自动编译，极大的提高了软件开发的效率。

​		Linux 环境下的程序员如果不会使用GNU make来构建和管理自己的工程，应该不能算是一个合格的专业程序员，至少不能称得上是 Unix程序员。在 Linux（unix ）环境下使用GNU 的make工具能够比较容易的构建一个属于你自己的工程，整个工程的编译只需要一个命令就可以完成编译、连接以至于最后的执行。不过这需要我们投入一些时间去完成一个或者多个称之为Makefile 文件的编写。

​		我们已经知道了 Makefile 描述的是文件编译的相关规则，它的规则主要是两个部分组成，分别是依赖的关系和执行的命令，其结构如下所示：

```makefile
targets : prerequisites
    command
```

翻译过来就是：

```
目标 ： 目标所有的依赖
	命令
```

看这个命令结构你可能还是搞不清楚什么意思。没关系 下面我来一点点的慢慢的进展。

#### 一个简单的程序

我们还是拿那个hello.c的文件来写。

```c
//hello.c
#include<stdio.h>

int main()
{
    printf("hello uos\n");
    return 0;
}
```

上面的是hello.c的内容，它的功能就是打印一个“hello uos”的字符串。我们需要怎么通过编写makefile文件来编译呢？这是一个最最最简单的makefile

```makefile
hello: hello.o
	gcc -o hello hello.o
hello.o:hello.c
	gcc -c hello.c
```

**注意**：

​		上面的makefile文件四行内容，gcc前面的空白部分是一个tab键，而不是四个空格。如果你是通过打空格的方式写的，在执行make的时候是不能够解析的。

在makefile文件对应的目录下,执行一个 make命令就行。如下所示：

```shell
$ ls
hello.c  Makefile
$ make
gcc -c  hello.c
gcc -o hello    hello.o
$ ls
hello  hello.c  hello.o  Makefile
$ ./hello
hello uos
```

​		我们可以看到，在我们执行执行make命令后，它自动的执行了gcc -c  hello.c和 gcc -o hello    hello.o这两条编译的命令。然后生成出了hello的可执行文件，运行可执行文件输出“hello uos”。



#### 复杂一点的工程

​		通过上面的简单的程序我们知道了基本的规则。现在我们来一个稍微复杂一点的例子。如果我的工程是一个mian.c和多个.c文件，.h文件组合起来的。

我们来看一下这个工程文件

```
.
├── main.c
├── Makefile
├── max.c
├── max.h
├── min.c
└── min.h
```

这个项目里有一个main.c主函数。内容为：

```c
#include "max.h"
#include "min.h"

#include <stdio.h>

int main()
{
	int _max = max(9,1);
	int _min = min(9,1);
	printf("max = %d\n", _max);
	printf("min = %d\n", _min);
	return 0;
}
```

它分别调用了max和min的两个函数。而这两个函数分别在max.c和min.c进行了实现。下面我们来看一下makefile文件里的内容：

```makefile
main: main.o max.o min.o  
	gcc -o main main.o max.o min.o 
main.o:main.c
	gcc -c main.c
max.o:	max.c
	gcc -c	max.c
min.o:	min.c
	gcc -c	min.c
```

执行make运行如下：

```shell
$ ls
main.c  Makefile  max.c  max.h  min.c  min.h
$ make
gcc -c main.c
gcc -c  max.c
gcc -c  min.c
gcc -o main main.o max.o min.o 
$ ls
main  main.c  main.o  Makefile  max.c  max.h  max.o  min.c  min.h  min.o
$ ./main
max = 9
min = 1
```

​		我这里想说两点：

​		⑴可以看出在我执行make命令后，出现了四条gcc的命令，它的顺序并不是和我们在编写makefile里面的顺序相同，对应makefile文件里的命令你会发现makeflile的运行的顺序逻辑，首先，在执行make这条命令后，就会去从上往下的执行makefile里的内容。在执行带main着一行的时候（也就是第一行），它会去找main：后面的所有的名字。发现main.o，它就会去下面找对应的main.o:，于是就跳转的main.o:。它发现max.o 下面有对应的max.o: 于是就跳转的max.o: 处去执行 然后会又 main：找下一个名字，min.o，直到main：这里的所有的名字（参数）找完，运行完之后最后运行main：下面的命令。

​		⑵我们执行完命令之后会生成很多.o文件，他们是链接时候需要用到到文件，我们编译完之后就已经不需要了，因此我们可以把它们删除掉，makefile里面有一个特定的命令（make clean）可以清理掉它们。

​		在makefile里面写下下面这条语句就可：

```makefile
main: main.o max.o min.o  
	gcc -o main main.o max.o min.o 
main.o:main.c
	gcc -c main.c
max.o:	max.c
	gcc -c	max.c
min.o:	min.c
	gcc -c	min.c
	
clean:
	rm *.o main
```

执行make clean后自动执行 makefile文件 clean: 的内容。

```shell
$ ls
main  main.c  main.o  Makefile  max.c  max.h  max.o  min.c  min.h  min.o
$ make clean
rm *.o main
$ ls
main.c  Makefile  max.c  max.h  min.c  min.h
```

这样，多个.c文件.h文件的项目也能通过makefile编译。

#### 多个主函数工程

​		有些时候，我们的工程项目里可能会有多个主函数的时候，这样我们怎么编译呢？

```shell
.
├── max.c
├── max.h
├── max_main.c
├── min.c
├── min.h
└── min_main.c
```

​		我们来看一下这个例子，这个代码和上面那个代码差不多，只是我创建了两个主函数，max_main.c它的内容就是调用max.c里面的max函数。 min_main.c调用min.c里的min函数。

```c
// max_main.c
#include "max.h"

#include <stdio.h>

int main()
{
	int _max = max(1,9);
	printf("max = %d\n", _max);
	return 0;
}

// min_main.c
#include "min.h"

#include <stdio.h>

int main()
{
	int _min = min(1,9);
	printf("min = %d\n", _min);
	return 0;
}
```

​		现在我们上面例子的思路来重新写一个makefile。这是我通过自己的理解，觉得两个主函数的makefile应该是这样写的：

```makefile
max_main:max_main.o	max.o
	gcc max_main.o max.o -o max_main
min_main:min_main.o	min.o
	gcc min_main.o min.o -o min_main
max_main.o: max_main.c
	gcc -c max_main.c
min_main.o: min_main.c
	gcc -c min_main.c
max.o:	max.c
	gcc -c	max.c
min.o:	min.c
	gcc -c	min.c
	
clean:
	rm *.o max_main min_main
```

​		我只是把我的main: 换成了max_main: 和 min_main: 我觉得这样它应该最终就会自动的运行gcc max_main.c max.o -o max_main 和 gcc min_main.c min.o -o min_main命令。

```shell
$ ls
Makefile  max.c  max.h  max_main.c  min.c  min.h  min_main.c
$ make
gcc -c max_main.c
gcc -c  max.c
gcc max_main.o max.o -o max_main
$ ls
Makefile  max.c  max.h  max_main  max_main.c  max_main.o  max.o  min.c  min.h  min_main.c
```

我make之后，发现它只执行里第一个max_main:的内容。max_main下面的min_main的部分没有执行。后来发现，makefile有一个关键字(**all**)来执行多个主函数功能。

修改后的makefile内容如下：

```makefile
all:max_main	min_main

max_main:max_main.o	max.o
	gcc max_main.o max.o -o max_main
min_main:min_main.o	min.o
	gcc min_main.o min.o -o min_main
max_main.o: max_main.c
	gcc -c max_main.c
min_main.o: min_main.c
	gcc -c min_main.c
max.o:	max.c
	gcc -c	max.c
min.o:	min.c
	gcc -c	min.c
	
clean:
	rm *.o max_main min_main
```

执行make之后

```shell
$ ls
Makefile  max.c  max.h  max_main  max_main.c  max_main.o  max.o  min.c  min.h  min_main.c
$ make
gcc -c min_main.c
gcc -c  min.c
gcc min_main.o min.o -o min_main
$ ls
Makefile  max.h     max_main.c  max.o  min.h     min_main.c  min.o
max.c     max_main  max_main.o  min.c  min_main  min_main.o
$ make clean
rm *.o max_main min_main
$ make
gcc -c max_main.c
gcc -c  max.c
gcc max_main.o max.o -o max_main
gcc -c min_main.c
gcc -c  min.c
gcc min_main.o min.o -o min_main
$ ./max_main
max = 9
$ ./min_main
min = 1
```

​		你会发现我上面的那一段里面执行了两次make命令，两次输出的结果也不一样，它就是我修改过后的makefile文件。

​		第一次执行make之后，你会发现它只编译了min_main的部分，这是因为之前max_main已经被编译过一次，产生了我们.o 和 可执行文件。 所有makefile会跳过已经编译过的代码。

​		第二次我在执行make前把.o和可执行文件都通过make clean删除掉了，所有我执行make之后，两个主函数都被编译过了。

​		**当我们想要编译多个主函数的时候，我们可以通过all: 后面加上我们的目标。**

#### 优化makefile文件1

​		通过上面的几个简单的例子，我相信基本的规则大家都已经知道了，但是我们一个也发现了一个问题，那就是makefile写起来好麻烦。

​		没关系，我们把第二个例子慢慢的一点点的修改。

​		下面是最初的makefile例子：

```makefile
main: main.o max.o min.o  
	gcc -o main main.o max.o min.o 
main.o:main.c
	gcc -c main.c -o main.o
max.o:	max.c
	gcc -c	max.c -o max.o
min.o:	min.c
	gcc -c	min.c -o min.o
	
clean:
	rm *.o main
```

​		1、我们发现，第一行的`main: main.o max.o min.o`和第二行的`gcc -o main main.o max.o min.o` 一大串的部分的是重复的。程序员都不喜欢做重复的事情，因此，我们可以把 `main.o max.o min.o`这种重复的内容赋给一个变量。那么第一行第二行就可以写成这样：

```makefile
OBJS=main.o max.o min.o
main: ${OBJS} 
	gcc -o main ${OBJS} 
```

​		2、还有如果我们想换一个编译器编译了比如g++，怎么办，是不是所有的gcc部分全都都要改成g++，这样一个个改的方法不妥当。所有我们应该把gcc也用一个变量来存储。如下图所示：

```makefile
OBJS=main.o max.o min.o
CC=gcc
main: ${OBJS} 
	${CC} -o main ${OBJS} 
main.o:main.c
	${CC} -c main.c -o main.o
max.o:	max.c
	${CC} -c max.c -o max.o
min.o:	min.c
	${CC} -c min.c -o min.o
	
clean:
	rm *.o main
```

​		3、有时候我们编译的时候需要知道警告，或者调试信息内容的，那我就要在${CC}（gcc）后边追加-Wall， -g等内容，这样我们又需要全部都追加一遍。有事一个重复的内容。因此，我们还是通过一个变量来存储。因此makefile就可以写成这样：

```makefile
OBJS=main.o max.o min.o
CC=gcc
CFLAGS=-c -Wall -g
main: ${OBJS} 
	${CC} -o main ${OBJS} 
main.o:main.c
	${CC} ${CFLAGS} main.c -o main.o
max.o:	max.c
	${CC} ${CFLAGS}	max.c -o max.o
min.o:	min.c
	${CC} ${CFLAGS}	min.c -o min.o
	
clean:
	rm *.o main
```

​		4、写到这里，我们发现还是有很多重复的内容， 大量的xxx.c 和 xxx.o。这里我要和大家讲几个超级有用的变量。

- $@ 目标文件
- $^  所有的依赖文件
- $<  第一个依赖文件

我们把：左边的叫做目标文件，右边的叫做依赖文件。有了这几个变量之后，我们的代码又可以进一步的简化了。

如下所示：

```makefile
OBJS=main.o max.o min.o
CC=gcc
CFLAGS=-c -Wall -g
main: ${OBJS} 
	${CC} -o main $^ 
main.o:main.c
	${CC} ${CFLAGS} $^ -o $@
max.o:	max.c
	${CC} ${CFLAGS}	$^ -o $@
min.o:	min.c
	${CC} ${CFLAGS}	$^ -o $@
	
clean:
	rm *.o main
```

​		5、我相信即使我把makefile优化到了这一步，还是会有很多小伙伴吐槽。这不是还有这么多xxx.o和xxx.c的文件吗？

​		那好，我来继续优化，被吐槽的确是事实，因为里面还是写了很多繁琐的东西。那么，我接下来再介绍一个用的符号。匹配符%。

​		Make命令允许对文件名，进行类似正则运算的匹配，主要用到的匹配符是%。有了%，就会匹配当前的文件夹下的所有的文件。也就是说：

```makefile
%.o:%.c

main.o:main.c
max.o:	max.c
min.o:	min.c
```

因此，我们有进一步的进行了优化。makefile内容如下：

```makefile
OBJS=main.o max.o min.o
CC=gcc
CFLAGS=-c -Wall -g
main: ${OBJS} 
	${CC} -o main $^ 
%.o:%.c
	${CC} ${CFLAGS} $^ -o $@
	
clean:
	rm *.o main
```

我们执行一下运行结果，如下：

```shell
$ ls
main.c  Makefile  max.c  max.h  min.c  min.h
$ make
gcc -c -Wall -g main.c -o main.o
gcc -c -Wall -g max.c -o max.o
gcc -c -Wall -g min.c -o min.o
gcc -o main main.o max.o min.o 
$ ls
main  main.c  main.o  Makefile  max.c  max.h  max.o  min.c  min.h  min.o
$ ./main
max = 9
min = 1
```

​		我们发现，还是可以编译最后得到我们的可执行程序。通过代码的一点点的优化，慢慢的得到了一个更方便实用的makefile代码。

#### 优化makefile文件2

​		我相信即使我做到了这一步，照样还是有很多喜欢“偷懒”的小伙伴还是会吐槽不方便。比如听到

​		懒癌A：“那些.o文件还是要让我们一个一个的添加咯？”

​		懒癌B：“我写了一百个类，每个都要OBJS=main.o max.o min.o...... 那我要写到什么时候。”

​		好吧，我承认，虽然你们是懒，但是说起话来真的处处是道理。的确，如果我们用到上面的写法，我们在增加项目代码和删除项目代码的时候会很不方便。因此在这里，我给你们介绍两个makefile的函数。

- wildcard

  wildcard的功能是获取到你**指定的目录**的**指定文件类型**的文件，然后返回这些名字。有了这个函数，我们通过一个目录就可以得到改目录的所有的文件名。

  通常的写法如下：

  ``` makefile
  SrcFiles=$(wildcard *.cpp)
  ```

  这条语句的意思是把当前makefile文件下的所有.cpp的文件保存到变量SrcFiles里。

- patsubst 

  patsubst的功能是把一个变量里的文件通过你的方式进行替换。返回替换之后的文件名。

  通常和wildcard函数一起用。写法如下：

  ```makefile
  ObjFiles=$(patsubst %.cpp,%.o,$(SrcFiles)) 
  ```

  这条语句的意思是把SrcFiles里的所有.cpp文件都替换成.o文件。

  通过这两个函数，自动的获取到你工程目录的所有文件名了。

#### 多个目录的工程

接下来我们了来看这个工程的目录结构：

```
.
├── book
│   ├── Book.cpp
│   └── Book.h
├── main.cpp
├── Makefile
└── person
    ├── Person.cpp
    ├── Person.h
    └── student
        ├── Student.cpp
        └── Student.h
```

这个工程对比之前的工程要复杂一些,它对应了多个目录,mian.cpp依赖了book目录的Book类,person目录的Person类和/person/student目录下的Student类。

来看一下main.cpp的内容吧：

```c++
#include "person/Person.h"
#include "book/Book.h"
#include "person/student/Student.h"

#include <iostream>

using namespace std;
int main() 
{
    Person person;
    Student student;
    student.name = "小明";
    person.name = "小刚";
    person.eating();
    person.sleeping();
    student.eating();
    student.sleeping();
    Book book("Qt设计模式");
    book.printName();
    return 0;
}
```

内容很简单，通过Person类，Student类，Book类创建了三个对象，比调用他们的函数。

通过我所说的那些知识，写出的makefile如下：

```makefile
SrcFiles=$(wildcard *.cpp ./person/*.cpp ./person/student/*.cpp ./book/*.cpp)       
ObjFiles=$(patsubst %.cpp,%.o,$(SrcFiles))   

$(info SrcFiles = $(SrcFiles)”)
$(info ObjFiles = $(ObjFiles)”)

CXX=g++
     		
all:app    				

app:$(ObjFiles)
	$(CXX) -o app $^

%.o:%.c                   
	$(CXX) -o $@ -c $^ 

clean:
	rm -rf $(ObjFiles) app
```

执行make编译如下：

```shell
$ ls
book  main.cpp  Makefile  person
$ make
SrcFiles = main.cpp ./person/Person.cpp ./person/student/Student.cpp ./book/Book.cpp”
ObjFiles = main.o ./person/Person.o ./person/student/Student.o ./book/Book.o   ”
g++    -c -o main.o main.cpp
g++    -c -o person/Person.o person/Person.cpp
g++    -c -o person/student/Student.o person/student/Student.cpp
g++    -c -o book/Book.o book/Book.cpp
g++ -o app main.o person/Person.o person/student/Student.o book/Book.o
$ ./app       
人小刚在吃
人小刚在睡觉
学生小明在吃
学生小明在睡觉
Qt设计模式
```

这样，多个目录结构的工程也能通过makefile编译了。并且随意的扩充我们的源代码。

#### 结语

以上就是一个makefile初学者通过学习对makefile的见解，makefile很强大，功能远远不止我介绍的这么多。我通过自己一点点扩展，只是想写一个尽量少改写我们的makefile文件，而多的随意扩充我们的项目而已。希望能带领你们入门，认识到makefile。如果你想要的功能没有得到解决，可以在网络上看看makefile的其他的用法。

我是一个Linux的初学者，希望以上有错误和不妥的地方还请指出。

PS：这篇文章的前面的变量名为都是用${ }来写的，到了后面讲到函数的时候我重新改用$( )这是因为我发现$( )似乎看的更明了。而且网络上的makefile例子也基本上都是$( )修饰的。

