#ifndef MAX_H
#define MAX_H

int max(int a,int b);



#endif //MAX_H