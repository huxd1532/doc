#include "max.h"
#include "min.h"

#include <stdio.h>

int main()
{
	int _max = max(9,1);
	int _min = min(9,1);
	printf("max = %d\n", _max);
	printf("min = %d\n", _min);
	return 0;
}