#ifndef MIN_H
#define MIN_H

int min(int a, int b);



#endif //MIN_H