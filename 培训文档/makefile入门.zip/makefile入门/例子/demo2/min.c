#include "min.h"

int min(int a, int b)
{
	return a<b?a:b;
}