#include <iostream>
#include "person/Person.h"
#include "book/Book.h"
#include "person/student/Student.h"

using namespace std;
int main() {
    Person person;
    Student student;
    student.name = "小明";
    person.name = "小刚";
    person.eating();
    person.sleeping();
    student.eating();
    student.sleeping();
    Book book("Qt设计模式");
    book.printName();
    return 0;
}
