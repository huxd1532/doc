//
// Created by wanjian on 2021/7/28.
//

#ifndef CPPTEST_PERSON_H
#define CPPTEST_PERSON_H
#include <iostream>


class Person {
public:
    std::string name;
    Person();
    ~Person();
    virtual void eating();
    virtual void sleeping();
};


#endif //CPPTEST_PERSON_H
