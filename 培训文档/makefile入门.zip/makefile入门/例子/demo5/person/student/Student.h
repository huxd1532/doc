//
// Created by wanjian on 2021/7/28.
//

#ifndef CPPTEST_STUDENT_H
#define CPPTEST_STUDENT_H
#include "../Person.h"

class Student : public Person{
public:
    Student();
    ~Student();
    void eating();
    void sleeping();
};


#endif //CPPTEST_STUDENT_H
