//
// Created by wanjian on 2021/7/28.
//

#include "Student.h"

Student::Student()
{

}
Student::~Student()
{

}
void Student::eating()
{
    std::cout << "学生" << this->name << "在吃" << std::endl;
}
void Student::sleeping()
{
    std::cout << "学生" << this->name << "在睡觉" << std::endl;
}