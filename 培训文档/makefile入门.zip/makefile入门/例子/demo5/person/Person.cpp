//
// Created by wanjian on 2021/7/28.
//

#include "Person.h"

Person::Person()
{

}

Person::~Person()
{

}
void Person::eating()
{
    std::cout << "人" << this->name << "在吃" << std::endl;
}

void Person::sleeping()
{
    std::cout << "人" << this->name << "在睡觉" << std::endl;
}
