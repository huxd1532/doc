//
// Created by wanjian on 2021/7/28.
//

#ifndef CPPTEST_BOOK_H
#define CPPTEST_BOOK_H

#include <iostream>

class Book {
public:
    std::string name;
    Book();
    Book(std::string name);
    ~Book();
    void printName();
};


#endif //CPPTEST_BOOK_H
