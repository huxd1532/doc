//
// Created by wanjian on 2021/7/28.
//

#include "Book.h"

Book::Book()
{

}
Book::Book(std::string name)
{
    this->name = name;
}
Book::~Book()
{

}
void Book::printName()
{
    std::cout << this->name << std::endl;
}
