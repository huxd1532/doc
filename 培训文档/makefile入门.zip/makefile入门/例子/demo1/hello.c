#include<stdio.h>

int main()
{
    printf("hello uos\n");
    return 0;
}