#include "min.h"

#include <stdio.h>

int main()
{
	int _min = min(1,9);
	printf("min = %d\n", _min);
	return 0;
}