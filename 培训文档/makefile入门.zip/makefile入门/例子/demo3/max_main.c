#include "max.h"

#include <stdio.h>

int main()
{
	int _max = max(1,9);
	printf("max = %d\n", _max);
	return 0;
}